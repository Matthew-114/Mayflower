---
title: 18 - Beggars
date: 2020-04-15
---
# 18 - Beggars

Presented and Sponsored by Board Member: `FireMarshaIBillBurns`

Be it enacted by the County Councillors and County Commissioners here assembled that

__**THE BOARD OF NEW HAVEN COUNTY ENACTS**__

<div class="list-county" markdown="1">

## Section I - Definitions

1. **Beggar** - An individual who verbally asks, requests, or begs for money.
2. **Public Place** - Public or private property that is open for the enjoyment or usage of the public.

## Section II - Text

1. A beggar who intimidates, harasses, threatens, or blocks the road in a public space is guilty of Disturbing the Peace and shall be fined 100 dollars.
2. A beggar who repeatedly offends is guilty of Disturbing the Peace and shall be arrested for 5 minutes.

## Section III - General Provisions

1. Upon this County Ordnance being published, it shall go into effect immediately. All conflicting Municipal Ordinances & County Ordinances will be declared null and void.

</div>

# Home

!!! warning
    This website is still under construction! The legality of any currently hosted legislation is not guaranteed.

Welcome to the State of Mayflower legislation site. This site's purpose is to host and maintain updates to various levels of legislation within the State of Mayflower:

- State
- County
- Municipal

